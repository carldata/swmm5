# swmm5-api

### How to use 
#### Run model
```python
from swmm5.basic_api import run_swmm

run_swmm("ParallelPumpConfiguration.inp")
```


### About exec files
Linux lib comes from great project https://github.com/aerispaha/swmmio/tree/master/lib

### Pandas support
More complex solutions will be based on another project https://gitlab.com/markuspichler/swmm_api/-/tree/master/